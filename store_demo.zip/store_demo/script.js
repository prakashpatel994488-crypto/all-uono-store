// script.js - demo interactivity (no external libs)

const demoApps = [
  {id:1, name:'ChatSpark', category:'Productivity', rating:4.6, size:'24 MB', desc:'AI chat companion for daily tasks and micro automation.', img:'assets/app1.jpg', bonus:'₹50', minWithdraw:'₹200'},
  {id:2, name:'PixelRunner', category:'Games', rating:4.3, size:'48 MB', desc:'Endless runner with retro pixel art and leaderboards.', img:'assets/app2.jpg', bonus:'₹30', minWithdraw:'₹100'},
  {id:3, name:'PhotoForge', category:'Photography', rating:4.7, size:'78 MB', desc:'Pro-level photo editor with one-tap filters and AI tools.', img:'assets/app3.jpg', bonus:'₹80', minWithdraw:'₹300'},
  {id:4, name:'MoneyMate', category:'Finance', rating:4.2, size:'15 MB', desc:'Smart expense tracker and budgeting assistant.', img:'assets/app4.jpg', bonus:'₹40', minWithdraw:'₹150'},
  {id:5, name:'StudyBuddy', category:'Education', rating:4.8, size:'32 MB', desc:'Flashcards, quizzes and study timers for focused learning.', img:'assets/app5.jpg', bonus:'₹60', minWithdraw:'₹250'}
];

const productsGrid = document.getElementById('productsGrid');
const trendingGrid = document.getElementById('trendingGrid');
const categoriesWrap = document.getElementById('categories');
const searchInput = document.getElementById('search');
const searchAside = document.getElementById('searchAside');
const modal = document.getElementById('modal');
const modalBody = document.getElementById('modalBody');
const modalClose = document.getElementById('modalClose');
const modalCloseBtn = document.getElementById('modalCloseBtn');
const yearSpan = document.getElementById('year');
const telegramBtn = document.getElementById('telegramBtn');

yearSpan.textContent = new Date().getFullYear();
telegramBtn.href = '#'; // set your telegram link here

function renderCategories(){
  const cats = ['All', ...Array.from(new Set(demoApps.map(a=>a.category)))];
  categoriesWrap.innerHTML = '';
  cats.forEach(c=>{
    const btn = document.createElement('button');
    btn.textContent = c;
    btn.onclick = ()=>{ filterState.category = c; render(); };
    categoriesWrap.appendChild(btn);
  });
}

const filterState = { query:'', category:'All' };

function matches(app){
  const q = filterState.query.trim().toLowerCase();
  const matchQ = !q || app.name.toLowerCase().includes(q) || app.desc.toLowerCase().includes(q);
  const matchC = filterState.category === 'All' || app.category === filterState.category;
  return matchQ && matchC;
}

function render(){
  const items = demoApps.filter(matches);
  productsGrid.innerHTML = '';
  items.forEach(app=>{
    const el = document.createElement('div');
    el.className = 'product';
    el.innerHTML = `
      <div style="display:flex;gap:12px;align-items:center">
        <img src="${app.img}" class="prod-illus" alt="${app.name}" />
        <div style="flex:1">
          <div class="prod-row">
            <div>
              <div class="prod-title">${app.name}</div>
              <div class="prod-desc">${app.category} • ${app.size}</div>
            </div>
            <div style="text-align:right">
              <div style="font-weight:700">${app.rating}★</div>
              <div style="color:#10b981;font-weight:700;margin-top:6px">${app.bonus}</div>
            </div>
          </div>
          <p class="prod-desc" style="margin-top:8px">${app.desc}</p>
        </div>
      </div>
      <div class="prod-actions">
        <div class="prod-meta">Min withdraw: <strong>${app.minWithdraw}</strong></div>
        <div>
          <button class="btn-download">Download</button>
        </div>
      </div>
    `;
    el.onclick = ()=> openModal(app);
    el.querySelector('.btn-download').onclick = (e)=>{ e.stopPropagation(); alert('Pretend download started for ' + app.name); };
    productsGrid.appendChild(el);
  });

  // trending
  trendingGrid.innerHTML = '';
  demoApps.slice(0,4).forEach(a=>{
    const t = document.createElement('div');
    t.className = 'trend-item';
    t.innerHTML = `<img src="${a.img}" style="width:46px;height:46px;border-radius:8px;object-fit:cover"/><div style="font-weight:700">${a.name}</div>`;
    trendingGrid.appendChild(t);
  });
}

function openModal(app){
  modalBody.innerHTML = `
    <div style="display:flex;gap:16px">
      <img src="${app.img}" style="width:96px;height:96px;border-radius:12px;object-fit:cover"/>
      <div>
        <h3 style="margin:0">${app.name}</h3>
        <div style="color:${'#6b7280'};font-size:13px;margin-top:6px">${app.category} • ${app.size} • ${app.rating}★</div>
        <p style="margin-top:12px;color:#0f172a">${app.desc}</p>
        <div style="margin-top:10px;display:flex;gap:8px">
          <button class="btn-download" onclick="(function(e){e.stopPropagation();alert('Pretend download for ${app.name}')})(event)">Download APK</button>
          <a class="btn btn-telegram" href="#" onclick="(function(e){e.stopPropagation();alert('Open Telegram')})(event)">Ask on Telegram</a>
        </div>
      </div>
    </div>
  `;
  modal.classList.add('show');
  modal.setAttribute('aria-hidden','false');
}

modalClose.onclick = ()=>{ modal.classList.remove('show'); modal.setAttribute('aria-hidden','true'); };
modalCloseBtn.onclick = ()=>{ modal.classList.remove('show'); modal.setAttribute('aria-hidden','true'); };
searchInput.oninput = (e)=>{ filterState.query = e.target.value; render(); };
searchAside.oninput = (e)=>{ filterState.query = e.target.value; render(); };

renderCategories();
render();
