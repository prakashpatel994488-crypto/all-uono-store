
# YourBrand Store — Demo (static files)

This is a ready-to-upload static demo of the modern light app store we built together.
Files include:
- index.html
- style.css
- script.js
- assets/ (images used by the demo)

How to deploy to GitHub Pages:
1. Create a new repository on GitHub.
2. Upload all files and folders from this project (you can drag & drop).
3. Commit changes.
4. Go to the repository Settings → Pages → Source → choose `main` branch / `root` → Save.
5. After a minute, your site will be live at: https://YOUR_USERNAME.github.io/YOUR_REPO_NAME

If you want, I can upload this to a GitHub repo for you or provide a ZIP file to download.
